package controlador;

/*
  Michael Jaramillo Palacio
  29/01/2025
  Descripcion: Programa que funciona como una tragaperra y se pueden bloquear
  numeros y desbloquearlos.
  No te salta el mensaje hasta que los x casillas de numeros esten todas con el
  mismo numero.
*/
public class Main {
    public static void main(String[] args) {
        new CTraga();
    }
}